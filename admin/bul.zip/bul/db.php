<?php

try {
    $db = new PDO("mysql:host=localhost;dbname=c1832965c_unigom", "c1832965c", "t6NA7V5NASdKwjX");
    $db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_WARNING);
} catch (PDOExeption $e) {
    die('Erreur : ' . $e->getMessage());
}

